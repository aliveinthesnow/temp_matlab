clear all;
clc;
R=10;L=0.01;V=2;i0=0;
tspan=[0 0.1]
[t i]=ode45(@(t,i)(V-i*R)/L,tspan,i0);
figure;
plot(t,i,'b','LineWidth',2);
xlabel('Time(sec)');
ylabel('Current i(t) A');
title('Current through inductor in RL circuit');