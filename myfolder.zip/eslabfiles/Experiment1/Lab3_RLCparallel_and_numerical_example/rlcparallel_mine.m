clear all;
clc;
close all;
Vs=5;R=100;Is = Vs/R;L = 10e-3;C = 100e-9;h = 1e-6;t0 = 0;tf = 0.002;     
t = t0:h:tf;
N = length(t);
f1 = @(t, v, i_L) (Is - v/R - i_L) / C;
f2 = @(t, v, i_L) v / L;
v_rk4 = zeros(1, N);
iL_rk4 = zeros(1, N);

for j = 1:(N-1)
    k1 = f1(t(j), v_rk4(j), iL_rk4(j));
    m1 = f2(t(j), v_rk4(j), iL_rk4(j));
    
    k2 = f1(t(j) + 0.5*h, v_rk4(j) + 0.5*h*k1, iL_rk4(j) + 0.5*h*m1);
    m2 = f2(t(j) + 0.5*h, v_rk4(j) + 0.5*h*k1, iL_rk4(j) + 0.5*h*m1);
    
    k3 = f1(t(j) + 0.5*h, v_rk4(j) + 0.5*h*k2, iL_rk4(j) + 0.5*h*m2);
    m3 = f2(t(j) + 0.5*h, v_rk4(j) + 0.5*h*k2, iL_rk4(j) + 0.5*h*m2);
    
    k4 = f1(t(j) + h, v_rk4(j) + h*k3, iL_rk4(j) + h*m3);
    m4 = f2(t(j) + h, v_rk4(j) + h*k3, iL_rk4(j) + h*m3);
    
    v_rk4(j+1) = v_rk4(j) + (h/6) * (k1 + 2*k2 + 2*k3 + k4);
    iL_rk4(j+1) = iL_rk4(j) + (h/6) * (m1 + 2*m2 + 2*m3 + m4);
end  
iR_rk4 = v_rk4 / R;                          
iC_rk4 = Is - iR_rk4 - iL_rk4; 
figure;
subplot(2,1,1);
plot(t, v_rk4, 'b-', 'LineWidth', 2);
legend('Capacitor Voltage (vc)')
subplot(2,1,2)
plot(t, iR_rk4, 'g-', 'LineWidth', 2); hold on;
plot(t, iL_rk4, 'r--', 'LineWidth', 2);hold on;
plot(t, iC_rk4, 'm-.', 'LineWidth', 2);hold on;

legend('Resistor Current (i_R)', 'Inductor Current (i_L)', 'Capacitor Current (i_C)');