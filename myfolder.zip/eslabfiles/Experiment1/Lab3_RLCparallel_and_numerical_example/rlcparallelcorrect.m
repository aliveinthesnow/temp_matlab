clear; clc; close all;

%% 1. Circuit Parameters
R = 100; % Resistance in Ohms
L = 0.01; % Inductance in Henrys
C = 100e-9; % Capacitance in Farads (10 nF)
V_in = 10; % Input Target Step Voltage (V)

% Equivalent Norton input step current source
I_source = V_in / R; 

%% 2. Runge-Kutta (RK4) Setup
t_start = 0;
t_end = 0.001; % 30 microseconds total simulation time
dt = 1e-8; % Fixed time step size (10 nanoseconds)
t = t_start:dt:t_end; % Time vector
N = length(t);

% Pre-allocate state vector arrays for speed
% State 1: v_C (Capacitor Voltage)
% State 2: i_L (Inductor Current)
v_C = zeros(1, N);
i_L = zeros(1, N);

% Initial Conditions (Zero energy at t=0)
v_C(1) = 0;
i_L(1) = 0;

%% 3. System System Derivatives (dx/dt = f(t, x))
% x = [v_C; i_L]
% dv_C_dt = (I_source - v_C/R - i_L) / C
% di_L_dt = v_C / L
f1 = @(v, i) (I_source - v/R - i) / C;
f2 = @(v, i) v / L;

%% 4. RK4 Integration Loop
for k = 1:(N-1)
    % Coefficients for current step k
    v_k = v_C(k);
    i_k = i_L(k);
    
    % K1 slopes
    kv1 = f1(v_k, i_k);
    ki1 = f2(v_k, i_k);
    
    % K2 slopes (at half time step)
    kv2 = f1(v_k + 0.5*dt*kv1, i_k + 0.5*dt*ki1);
    ki2 = f2(v_k + 0.5*dt*kv1, i_k + 0.5*dt*ki1);
    
    % K3 slopes (at half time step updated)
    kv3 = f1(v_k + 0.5*dt*kv2, i_k + 0.5*dt*ki2);
    ki3 = f2(v_k + 0.5*dt*kv2, i_k + 0.5*dt*ki2);
    
    % K4 slopes (at next time step)
    kv4 = f1(v_k + dt*kv3, i_k + dt*ki3);
    ki4 = f2(v_k + dt*kv3, i_k + dt*ki3);
    
    % Update next state values using weighted average of slopes
    v_C(k+1) = v_k + (dt/6) * (kv1 + 2*kv2 + 2*kv3 + kv4);
    i_L(k+1) = i_k + (dt/6) * (ki1 + 2*ki2 + 2*ki3 + ki4);
end

%% 5. Calculate Resistor and Capacitor Currents
i_R = v_C / R; % Ohm's law across parallel node
i_C = I_source - i_R - i_L; % Kirchhoff's Current Law (KCL)

%% 6. Plotting Graphs
figure('Color', 'w');

% Plot Capacitor Voltage
subplot(2,1,1);
plot(t * 1e6, v_C, 'b-', 'LineWidth', 2);
grid on;
title('Voltage across Capacitor $v_C(t)$ [RK4 Method]', 'Interpreter', 'latex', 'FontSize', 12);
xlabel('Time ($\mu$s)', 'Interpreter', 'latex');
ylabel('Voltage (V)');

% Plot Branch Currents
subplot(2,1,2);
plot(t * 1e6, i_R * 1000, 'g-', 'LineWidth', 2); hold on;
plot(t * 1e6, i_L * 1000, 'r--', 'LineWidth', 2);
plot(t * 1e6, i_C * 1000, 'm-.', 'LineWidth', 2);
grid on;
title('Currents through Branch Elements [RK4 Method]', 'Interpreter', 'latex', 'FontSize', 12);
xlabel('Time ($\mu$s)', 'Interpreter', 'latex');
ylabel('Current (mA)');
legend('Resistor Current ($i_R$)', 'Inductor Current ($i_L$)', 'Capacitor Current ($i_C$)', ...
       'Interpreter', 'latex', 'Location', 'best');