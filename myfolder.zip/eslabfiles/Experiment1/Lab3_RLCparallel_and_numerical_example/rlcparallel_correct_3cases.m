clear all;
clc;
close all;
Vs=5;L=10e-3;C=100e-9;
h=1e-6;
t0=0;
tf=0.002;
Rc=0.5*sqrt(L/C);
R_values=[300 Rc 100];
case_name={'Underdamped','Critically Damped','Overdamped'};
for m=1:3
R=R_values(m);
Is=Vs/R;
t=t0:h:tf;
N=length(t);
f1=@(t,v,iL)(Is-v/R-iL)/C;
f2=@(t,v,iL)v/L;
v=zeros(1,N);
iL=zeros(1,N);
for j=1:(N-1)
k1=f1(t(j),v(j),iL(j));
m1=f2(t(j),v(j),iL(j));
k2=f1(t(j)+0.5*h,v(j)+0.5*h*k1,iL(j)+0.5*h*m1);
m2=f2(t(j)+0.5*h,v(j)+0.5*h*k1,iL(j)+0.5*h*m1);
k3=f1(t(j)+0.5*h,v(j)+0.5*h*k2,iL(j)+0.5*h*m2);
m3=f2(t(j)+0.5*h,v(j)+0.5*h*k2,iL(j)+0.5*h*m2);
k4=f1(t(j)+h,v(j)+h*k3,iL(j)+h*m3);
m4=f2(t(j)+h,v(j)+h*k3,iL(j)+h*m3);
v(j+1)=v(j)+(h/6)*(k1+2*k2+2*k3+k4);
iL(j+1)=iL(j)+(h/6)*(m1+2*m2+2*m3+m4);
end
iR=v/R;
iC=Is-iR-iL;
alpha=1/(2*R*C);
omega0=1/sqrt(L*C);
figure;
subplot(2,1,1);
plot(t,v,'b-','LineWidth',2);
grid on;
xlabel('Time (ms)');
ylabel('Voltage (V)');
title([case_name{m},' - Capacitor Voltage (R = ',num2str(R,'%.2f'),' \Omega)']);
legend('v_C','Location','best');
subplot(2,1,2);
plot(t,iR,'g-','LineWidth',2);
hold on;
plot(t,iL,'r--','LineWidth',2);
plot(t,iC,'m-.','LineWidth',2);
plot(t,iR+iL+iC,'k:','LineWidth',1.5);
grid on;
xlabel('Time (ms)');
ylabel('Current (A)');
title([case_name{m},' - Branch Currents']);
legend('i_R','i_L','i_C','i_{Total}','Location','best');
end
disp('---------------------------------------------');
disp('Parallel RLC Damping Information');
disp('---------------------------------------------');
for m=1:3
fprintf('%s\n',case_name{m});
fprintf('R = %.2f Ohms\n',R_values(m));
fprintf('alpha = %.2f rad/s\n',1/(2*R_values(m)*C));
fprintf('omega0 = %.2f rad/s\n\n',omega0);
end