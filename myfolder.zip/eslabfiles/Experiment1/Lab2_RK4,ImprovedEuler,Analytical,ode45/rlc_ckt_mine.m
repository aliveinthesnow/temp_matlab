clear all;
clc;
close all;
V=5;R=10;L=0.1;C=0.0001;h=0.001;i0=0;vc0=0;t0=0;tf=0.1;
t=t0:h:tf;
N=length(t);
f1=@(t,vc,i)(V-i*R-vc)/L;
f2=@(t,vc,i)(i/C);
i=zeros(1,N);
vc=zeros(1,N);
i(1)=i0;
vc(1)=vc0;
for j=1:(N-1)
    k1=f1(t(j),vc(j),i(j));
    m1=f2(t(j),vc(j),i(j));
    k2=f1(t(j)+h,vc(j)+h*m1,i(j)+h*k1);
    m2=f2(t(j)+h,vc(j)+h*m1,i(j)+h*k1);
    i(j+1)=i(j)+(h/2)*(k1+k2);
    vc(j+1)=vc(j)+(h/2)*(m1+m2);
end    
figure;
plot(t,i,'r');
hold on;
plot(t,vc,'b')
hold on;
for j=1:(N-1)
    k1=f1(t(j),vc(j),i(j));
    m1=f2(t(j),vc(j),i(j));
    k2=f1(t(j)+0.5*h,vc(j)+0.5*h*m1,i(j)+0.5*h*k1);
    m2=f2(t(j)+0.5*h,vc(j)+0.5*h*m1,i(j)+0.5*h*k1);
    k3=f1(t(j)+0.5*h,vc(j)+0.5*h*m2,i(j)+0.5*h*k2);
    m3=f2(t(j)+0.5*h,vc(j)+0.5*h*m2,i(j)+0.5*h*k2);
    k4=f1(t(j)+h,vc(j)+h*m3,i(j)+h*k3);
    m4=f2(t(j)+h,vc(j)+h*m3,i(j)+h*k3);
   i(j+1)=i(j)+(h/6)*(k1+2*k2+2*k3+k4);
   vc(j+1)=vc(j)+(h/6)*(m1+2*m2+2*m3+m4);
end  
plot(t,i,'g');
hold on;
plot(t,vc,'y');
hold on;
legend('current_improvedeuler','voltageimprovedeuler','current_RK4','voltage_RK4')
xlabel('Time');
ylabel('Current and voltage');

