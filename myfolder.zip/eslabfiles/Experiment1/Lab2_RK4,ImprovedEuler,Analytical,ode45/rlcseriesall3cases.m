clear all;clc;close all;
V=5;L=0.1;C=0.0001;h=0.001;i0=0;vc0=0;t0=0;tf=0.1;
Rcritical=2*sqrt(L/C);
Rvalues=[10 Rcritical 100];
cases={'Underdamped','Critically Damped','Overdamped'};
for c=1:3
R=Rvalues(c);
t=t0:h:tf;
N=length(t);
f1=@(t,vc,i)(V-i*R-vc)/L;
f2=@(t,vc,i)(i/C);
i=zeros(1,N);
vc=zeros(1,N);
i(1)=i0;
vc(1)=vc0;
for j=1:(N-1)
k1=f1(t(j),vc(j),i(j));
m1=f2(t(j),vc(j),i(j));
k2=f1(t(j)+h,vc(j)+h*m1,i(j)+h*k1);
m2=f2(t(j)+h,vc(j)+h*m1,i(j)+h*k1);
i(j+1)=i(j)+(h/2)*(k1+k2);
vc(j+1)=vc(j)+(h/2)*(m1+m2);
end
i_ie=i;
vc_ie=vc;
i=zeros(1,N);
vc=zeros(1,N);
i(1)=i0;
vc(1)=vc0;
for j=1:(N-1)
k1=f1(t(j),vc(j),i(j));
m1=f2(t(j),vc(j),i(j));
k2=f1(t(j)+0.5*h,vc(j)+0.5*h*m1,i(j)+0.5*h*k1);
m2=f2(t(j)+0.5*h,vc(j)+0.5*h*m1,i(j)+0.5*h*k1);
k3=f1(t(j)+0.5*h,vc(j)+0.5*h*m2,i(j)+0.5*h*k2);
m3=f2(t(j)+0.5*h,vc(j)+0.5*h*m2,i(j)+0.5*h*k2);
k4=f1(t(j)+h,vc(j)+h*m3,i(j)+h*k3);
m4=f2(t(j)+h,vc(j)+h*m3,i(j)+h*k3);
i(j+1)=i(j)+(h/6)*(k1+2*k2+2*k3+k4);
vc(j+1)=vc(j)+(h/6)*(m1+2*m2+2*m3+m4);
end
i_rk4=i;vc_rk4=vc;alpha=R/(2*L);
omega0=1/sqrt(L*C);
if alpha<omega0
zeta='Under';
elseif abs(alpha-omega0)<1e-10
zeta='Critical';
else
zeta='Over';
end
figure;
subplot(2,1,1);
plot(t,i_ie,'r--','LineWidth',2);
hold on;
plot(t,i_rk4,'g-','LineWidth',2);
legend('Improved Euler','RK4');
xlabel('Time (s)');
ylabel('Current (A)');
title([cases{c} ' - Current Waveform, R = ' num2str(R) ' \Omega']);
grid on;
subplot(2,1,2);
plot(t,vc_ie,'b--','LineWidth',2);
hold on;
plot(t,vc_rk4,'m-','LineWidth',2);
legend('Improved Euler','RK4');
xlabel('Time (s)');
ylabel('Voltage (V)');
title([cases{c} ' - Capacitor Voltage Waveform']);
grid on;end